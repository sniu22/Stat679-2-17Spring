// Last name: Niu
// First name: Shuo
// NetID: sniu22@wisc.edu

// queens.cxx: runs stack-based backtracking search to solve n-queens
// problem.

#include <iostream>
#include <string>
#include "Stack.h"

using namespace std;

// ... You're welcome to add function prototypes of your own design
// here.  Put corresponding implementations below main().

// Runs n-queens search.  Prints queen configuration if there's a
// solution; otherwise prints "no solution exists".  If "debug" is
// true, also prints each configuration of queens encountered during
// the search.
void queens_search(int n, bool debug);
bool safe(Stack<int> &queen);
void print_queen(Stack<int> &queen, int n);

// I've written main() for you.
int main(int argc, char *argv[]) {
    int n_queens;
    bool debug = false;

    if (!(argc == 2 || argc == 3)) {
	cerr << "usage: " << argv[0]
	     << " <n_queens> [<optional 'd' means debug>]"
	     << endl;
	return 0;
    }

    n_queens = atoi(argv[1]);
    if (argc == 3) {
	debug = (argv[2][0] == 'd');
    }

    queens_search(n_queens, debug);


//    queens_search(4,true);
    return 0;
}


void queens_search(int n, bool debug) {
    if (debug) {
	cerr << "n=" << n << ", debug=" << debug << endl;
    }

    Stack<int> queen = Stack<int>();
    queen.push(0);
    while(queen[0] < n && queen.size() <= n){
        if(queen[queen.size()-1] >= n){
            queen.pop();
            queen.push(queen.pop()+1);
            continue;
        }
        if (debug) print_queen(queen,n);
        if (safe(queen)){
            queen.push(0);
        } else queen.push(queen.pop()+1);
    }
    if (queen.size() == 0) cout << "No Solution" << endl;
    if (queen.size() == n) print_queen(queen,n);
}

bool safe(Stack<int> &queen){
    int row = queen.size() - 1;
    for (int i = 0; i < row ; ++i) {
        if (queen[i] == queen[row]) return false;
        if (queen[i] == (queen[row] - (row-i))) return false;
        if (queen[i] == (queen[row] + (row-i))) return false;
    }
    return true;
}

void print_queen(Stack<int> &queen, int n){
    string res_out = "stack: ";
    for (int k = 0; k < queen.size(); ++k) {
        res_out += to_string(queen[k]) + " ";
    }
    res_out += "\n";
    res_out += "---\n\nboard:\n";
    for (int i = 0; i < queen.size(); ++i) {
        for (int j = 0; j < n; ++j) {
            if (queen[i] == j) res_out += " Q |";
            else res_out += "   |";
        }
        res_out +="\n";
    }
    for (int i = queen.size(); i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            res_out += "   |";
        }
        res_out +="\n";
    }

    cout<< res_out << endl;
}