#include <iostream>
#include "Stack.h"
#include <string>
using namespace std;
int main() {

    int a[10] = {0};
    a[1] = 1;



    Stack<int> value = Stack<int>();

    string values = "bdshdbdfkjbvndfsvjf";

    cout<<values<<endl;
    cout<<false<<endl;




}